#pragma once

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include "cell.h"

using namespace std;

class Map
{
public:
	Map(string link);
	~Map();

	void printCells();
	void printRoute();

	int getDimensions(); // Always be a square

	Cell* getStart();
private:

	vector <Cell*> mapCells;

	Cell* startCell;

	int size;

};