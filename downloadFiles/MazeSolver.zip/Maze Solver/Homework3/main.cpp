#include <iostream>
#include <iomanip>
#include <string>
#include "Stack.h"
#include "Cell.h"
#include "Map.h"
#include "Tracker.h"

using namespace std;

int main()
{

	Map map("C:/Users/Austin/Desktop/3x3map.txt");

	//print the original cells from the file
	map.printCells();

	//create a tracker capable of traversing through a map
	Tracker tracker;

	//send the tracker to find a path through the map
	tracker.findPath(map);

	//print an X/O map from the start to the end
	map.printRoute();

	return 0;

	/*  Testing my Stack

	Stack < int > temp;

	temp.push(5);
	cout << temp.getSize() << endl;
	temp.pop();
	cout << temp.getSize() << endl;


	temp.push(1);
	temp.push(2);
	temp.push(3);

	cout << temp.getSize() << endl;
	cout << temp.pop() << endl;
	cout << temp.pop() << endl;
	cout << temp.pop() << endl;

	*/

}

