#pragma once

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include "Map.h"
#include "Stack.h"
#include "Cell.h"
#include "Tracker.h"

using namespace std;

Tracker::Tracker()
{
	p_head = NULL;
	hasFoundEnd = false;
}
Tracker::~Tracker()
{
	while (mainStack.getSize() != 0)
	{
		mainStack.pop();
	}
	
	p_head = NULL;
}
Tracker::Tracker(Map& obj)
{
	hasFoundEnd = false;
	findPath(obj);
}

void Tracker::moveNorth()
{
	if (p_head->getNorth() != NULL)
	{
		cout << "MOVING NORTH";

		p_head = p_head->getNorth();

		cout << " X:" << p_head->getX();
		cout << " Y:" << p_head->getY();
		cout << endl;
		// Set it as traversed
		p_head->setAsTraversed();

		// Push To stack
		mainStack.push(p_head);
	}
}
void Tracker::moveEast()
{
	if (p_head->getEast() != NULL)
	{
		cout << "MOVING EAST";

		p_head = p_head->getEast();

		cout << " X:" << p_head->getX();
		cout << " Y:" << p_head->getY();
		cout << endl;
		// Set it as traversed
		p_head->setAsTraversed();

		// Push To stack
		mainStack.push(p_head);
	}
}
void Tracker::moveSouth()
{
	if (p_head->getSouth() != NULL)
	{
		cout << "MOVING SOUTH";
		p_head = p_head->getSouth();

		cout << " X:" << p_head->getX();
		cout << " Y:" << p_head->getY();
		cout << endl;
		// Set it as traversed
		p_head->setAsTraversed();

		// Push To stack
		mainStack.push(p_head);
	}
}
void Tracker::moveWest()
{
	if (p_head->getWest() != NULL)
	{
		cout << "MOVING WEST";
		p_head = p_head->getWest();

		cout << " X:" << p_head->getX();
		cout << " Y:" << p_head->getY();
		cout << endl;
		// Set it as traversed
		p_head->setAsTraversed();

		// Push To stack
		mainStack.push(p_head);
	}
}

void Tracker::findPath(Map& obj)
{
	// Get the start
	p_head = obj.getStart();

	// Test the head to see if its on the right one
	//cout << p_head->getType() << endl;

	// Push head to the stack
	mainStack.push(p_head);

	cout << "STARTED AT POSITION X:" << p_head->getX() << " Y:" << p_head->getY() << endl;

	// Find Free Cell
	while(hasFoundEnd == false)
	{
		if (p_head->isNorthFree())
		{
			moveNorth();
			if (p_head->getType() == END)
			{
				hasFoundEnd = true;
				break;
			}
		}
		else if (p_head->isEastFree())
		{
			moveEast();
			if (p_head->getType() == END)
			{
				hasFoundEnd = true;
				break;
			}
		}
		else if (p_head->isSouthFree())
		{
			moveSouth();
			if (p_head->getType() == END)
			{
				hasFoundEnd = true;
				break;
			}
		}
		else if (p_head->isWestFree())
		{
			moveWest();
			if (p_head->getType() == END)
			{
				hasFoundEnd = true;
				break;
			}
		}
		else
		{
			// We need to backtrack NOW
			if (mainStack.getSize() == 0) 
			{
				// We're screwed...
				cout << "This map is unsolvable!" << endl;
				break;
			}
			else
			{
				// We're not screwed

				// Create temp pointer

				if (p_head->isAnyDirectionFree() == false)
				{

					cout << "BACKTRACKING FROM-";
					cout << " X:"<<  p_head->getX() << " Y:" << p_head->getY() << " TO:";
					mainStack.pop();
					p_head = mainStack.top();
					cout << " X:" << p_head->getX() << " Y:" << p_head->getY() << endl;

				}
			}
		}
	}

	for (int i = 0; i < mainStack.getSize(); i++)
	{
		Cell* p_temp;

		p_temp = mainStack.top();

		p_temp->setAsPartOfPath();

		mainStack.pop();

		i--;
	}
}