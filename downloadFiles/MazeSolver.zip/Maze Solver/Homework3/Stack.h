#pragma once

#include <iostream>
#include <iomanip>
#include "StackUnderflow.h"

using namespace std;

template <class T>
class Stack
{
public:
	Stack();
	~Stack();

	T& pop();
	T& top();
	void push(const T& item);
	int getSize();

private:

	struct Node
	{
		Node* p_next;
		T data;
	};

	Node* p_head;
	
	int size;

};

template <class T>
Stack <T>::Stack()
{
	size = 0;

	p_head = NULL;
}

template <class T>
Stack <T>::~Stack()
{
	if (getSize() == 0)
	{
		p_head = NULL;
	}
	else
	{
		while (getSize() > 0)
		{
			pop();

			p_head = NULL;
		}
	}
}

template <class T>
T& Stack <T>::pop()
{
	if (getSize() == 0)
	{
		StackUnderflow ex;
		throw ex;
	}
	else
	{
		T t_data = p_head->data;

		Node* temp = p_head;

		if (getSize() == 1)
		{
			p_head = NULL;
		}
		else
		{
			p_head = p_head->p_next;
		}

		delete temp;

		temp = NULL;

		size--;

		return t_data;
	}
}

template <class T>
void Stack <T>::push(const T& item)
{
	if (getSize() == 0) // Empty
	{
		Node* p_temp = new Node; // New node

		p_temp->data = item;

		p_temp->p_next = NULL;

		p_head = p_temp;

		size++;

		p_temp = NULL;
	}
	else
	{
		Node* p_temp = new Node;

		p_temp->data = item;

		p_temp->p_next = p_head;

		p_head = p_temp;

		size++;

		p_temp = NULL;
	}
}

 template <class T>
 int Stack <T>::getSize()
 {
	 return size;
 }

 template <class T>
 T& Stack <T>::top()
 {
	 return p_head->data;
 }