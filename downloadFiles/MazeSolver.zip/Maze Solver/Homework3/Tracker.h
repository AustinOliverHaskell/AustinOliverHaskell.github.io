#pragma once

#include <iostream>
#include <iomanip>
#include <string>
#include <vector>
#include "Map.h"
#include "Stack.h"
#include "Cell.h"

using namespace std;

class Tracker
{
public:
	Tracker();
	~Tracker();
	Tracker(Map& obj);

	void findPath(Map& obj);

	void moveNorth();
	void moveEast();
	void moveSouth();
	void moveWest();

private:
	Stack < Cell* > mainStack;

	bool hasFoundEnd;

	Cell* p_head;
};