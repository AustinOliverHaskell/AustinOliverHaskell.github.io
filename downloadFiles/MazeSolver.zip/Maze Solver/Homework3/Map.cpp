#include <iostream>
#include <iomanip>
#include <fstream>
#include <vector>
#include <string>
#include <cmath>
#include "Map.h"
#include "Cell.h"

using namespace std;

Map::Map(string link)
{


	// -------------------------------------------
	// Get from the file and fill a temporary list

	vector < char > temp; // Temp Vector for the temporary storage of the characters

	ifstream file(link);

	if (file.is_open()) // If succesfully open
	{
		char ctemp;
		while (file.good())
		{
			ctemp = file.get();

			if (ctemp == 'B' || ctemp == 'F' || ctemp == 'E' || ctemp == 'S')
			{
				temp.push_back(ctemp);
			}
		}
	}
	else
	{
		cout << "Error opening file" << endl;
	}

	size = temp.size();

	int dimention = sqrt(size);

	// -----------------------------------------
	//            Creation of the permanent list
	for (int i = 0; i < dimention; i++)
	{
		for (int j = 0; j < dimention; j++)
		{
			int type;

			if (temp[dimention*i+j] == 'F')
			{
				type = FREE;
			}
			else if (temp[dimention*i + j] == 'S')
			{
				type = START;
			}
			else if (temp[dimention*i + j] == 'E')
			{
				type = END;
			}
			else
			{
				type = BLOCKED;
			}

			// Setting the cell to its correct type and X Y cordanates
			Cell* p_temp = new Cell();

			if (type == START)
			{
				startCell = p_temp;
			}

			p_temp->setType(type);

			p_temp->setX(j%dimention);
			p_temp->setY(i%dimention);

			//p_temp->printConnections(); TEST TYPE SETTING

			mapCells.push_back(p_temp);

			p_temp = NULL;
		}

	}

	// -------------------------------------------
	//                                  Link columns
	for (int i = 0; i < size; i++)
	{
		if (i % dimention == 0) // Begining of row
		{
			mapCells[i]->setWest(NULL);
			mapCells[i]->setEast(mapCells[i + 1]);
		}
		else if (i % dimention == dimention - 1) // End of row
		{
			mapCells[i]->setWest(mapCells[i - 1]);
			mapCells[i]->setEast(NULL);
		}
		else // Good to go
		{
			mapCells[i]->setWest(mapCells[i - 1]);
			mapCells[i]->setEast(mapCells[i + 1]);
		}


		// SET THE UPPY DOWNY STUFF
		if (i + dimention < size) // Down
		{
			mapCells[i]->setSouth(mapCells[i + dimention]);
		}
		else
		{
			mapCells[i]->setSouth(NULL);
		}

		if (i - dimention >= 0) //Up
		{
			mapCells[i]->setNorth(mapCells[i - dimention]);
		}
		else
		{
			mapCells[i]->setNorth(NULL);
		}
	}

	/*
	for (int i = 0; i < size; i++)
	{
		mapCells[i]->printConnections();
	}
	*/
	
}
Map::~Map()
{
	cout << "THE DESTRUCTOR HAS BEEN CALLED. FEAR FOR YOUR LIFE SMALL HUMAN!!!!" << endl;
	for (int i = 0; i < mapCells.size(); i++)
	{
		mapCells[i]->setNorth(NULL);
		mapCells[i]->setSouth(NULL);
		mapCells[i]->setEast(NULL);
		mapCells[i]->setWest(NULL);

		delete mapCells[i];

		mapCells[i] = NULL;
	}
}

int Map::getDimensions()
{
	return sqrt(size);
}

Cell* Map::getStart()
{
	return startCell;
}

void Map::printCells()
{
	for (int i = 1; i <= size; i++)
	{
		mapCells[i-1]->printType();
		cout << " ";

			if (i % (getDimensions()) == 0)
			{
				cout << endl;
			}
	}

	cout << endl;
	cout << endl;

}
void Map::printRoute()
{
	cout << endl << endl;

	for (int i = 1; i <= size; i++)
	{
		if (mapCells[i-1]->partOfPath())
		{
			cout << "O ";
		}
		else
		{
			cout << "X ";
		}

		if (i % getDimensions() == 0 && i != 0)
		{
			cout << endl;
		}
	}

	cout << endl;
	cout << endl;
}
