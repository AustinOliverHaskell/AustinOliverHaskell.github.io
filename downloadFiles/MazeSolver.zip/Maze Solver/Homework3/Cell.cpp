#include <iostream>
#include <iomanip>
#include "Cell.h"

using namespace std;

// ********************************************************************************************************************************
//                                                                                                         CONSTRUCTORS/DESTRUCTORS
Cell::Cell()
{
	p_north = NULL;
	p_south = NULL;
	p_east = NULL;
	p_west = NULL;

	int x = 0;
	int y = 0;

	bool traversed = false;
	bool isPartOfPath = false;

	int type = BLOCKED;
}
Cell::Cell(int startX, int startY, int newType)
{
	p_north = NULL;
	p_south = NULL;
	p_east = NULL;
	p_west = NULL;

	int x = startX;
	int y = startY;

	bool traversed = false;
	bool free = false;
	bool start = false;
	bool end = false;
	bool isPartOfPath = false;

	type = newType;
}
Cell::~Cell()
{
	p_north = NULL;
	p_south = NULL;
	p_east = NULL;
	p_west = NULL;
}
// ********************************************************************************************************************************



// ********************************************************************************************************************************
//                                                                                                                          GETTERS
bool Cell::hasBeenTraversed()
{
	return traversed;
}
int Cell::getY()
{
	return y;
}
int Cell::getX()
{
	return x;
}
bool Cell::areStart()
{
	if (type == START)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Cell::areEnd()
{
	if (type == END)
	{
		return true;
	}
	else
	{
		return false;
	}
}
bool Cell::partOfPath()
{
	return isPartOfPath;
}
int Cell::getType()
{
	return type;
}

bool Cell::isNorthFree()
{
	bool retVal = false;

	if (p_north != NULL)
	{
		if ((p_north->getType() == FREE || p_north->getType() == END) && p_north->hasBeenTraversed() == false)
		{
			retVal = true;
		}
	}

	return retVal;

}
bool Cell::isEastFree()
{
	bool retVal = false;

	if (p_east != NULL)
	{
		if ((p_east->getType() == FREE || p_east->getType() == END) && p_east->hasBeenTraversed() == false)
		{
			retVal = true;
		}
	}

	return retVal;
}
bool Cell::isSouthFree()
{
	bool retVal = false;

	if (p_south != NULL)
	{
		if ((p_south->getType() == FREE || p_south->getType() == END) && p_south->hasBeenTraversed() == false)
		{
			retVal = true;
		}
	}

	return retVal;
}
bool Cell::isWestFree()
{
	bool retVal = false;

	if (p_west != NULL)
	{
		if ((p_west->getType() == FREE || p_west->getType() == END) && p_west->hasBeenTraversed() == false)
		{
			retVal = true;
		}
	}

	return retVal;
}

bool Cell::isAnyDirectionFree()
{
	if (isNorthFree() || isEastFree() || isSouthFree() || isWestFree())
	{
		return true;
	}
	else
	{
		return false;
	}
}

Cell* Cell::getNorth()
{
	return p_north;
}
Cell* Cell::getEast()
{
	return p_east;
}
Cell* Cell::getSouth()
{
	return p_south;
}
Cell* Cell::getWest()
{
	return p_west;
}
// ********************************************************************************************************************************



// ********************************************************************************************************************************
//                                                                                                                           SETERS
void Cell::setNorth(Cell* p_point)
{
	setSide(p_point, 0);
}
void Cell::setEast(Cell* p_point)
{
	setSide(p_point, 1);
}
void Cell::setSouth(Cell* p_point)
{
	setSide(p_point, 2);
}
void Cell::setWest(Cell* p_point)
{
	setSide(p_point, 3);
}
void Cell::setSide(Cell* p_point, int direction)
{
	if (direction == 0) // North
	{
		p_north = p_point;
	}
	else if (direction == 1) // East
	{
		p_east = p_point;
	}
	else if (direction == 2) // South
	{
		p_south = p_point;
	}
	else // West
	{
		p_west = p_point;
	}
}

void Cell::setX(int newX)
{
	x = newX;
}
void Cell::setY(int newY)
{
	y = newY;
}

void Cell::changeType(int newType)
{
	type = newType;
}

void Cell::setAsStart()
{
	type = START;
}
void Cell::setAsEnd()
{
	type = END;
}

void Cell::setType(int t)
{
	type = t;
}

void Cell::setAsTraversed()
{
	traversed = true;
}
void Cell::setAsPartOfPath()
{
	isPartOfPath = true;
}
// ********************************************************************************************************************************



// ********************************************************************************************************************************
//                                                                                                                            PRINT
void Cell::printConnections()
{

	cout << endl << endl;
	cout << "::::::::::::::::::::::::::::::::::::::::::::::::::" << endl;
	cout << ":::::                CORDANATES              :::::" << endl;
	cout << ":: MINE:  X:" << getX() << " Y:" << getY() << endl;


	// ***************************************
	if (p_north != NULL)
	{
		cout << ":: NORTH:  X:" << p_north->getX() << " Y:" << p_north->getY() << endl;
	}
	else
	{
		cout << "::: NO POINTER TO THE NORTH OR POINTER IS NULL :::"<< endl;
	}
	// ***************************************


	// ***************************************

	if (p_east != NULL)
	{
		cout << ":: EAST:  X:" << p_east->getX() << " Y:" << p_east->getY() << endl;
	}
	else
	{
		cout << "::: NO POINTER TO THE EAST OR POINTER IS NULL:::" << endl;
	}
	// ***************************************


	// ***************************************
	if (p_south != NULL)
	{
		cout << ":: SOUTH:  X:" << p_south->getX() << " Y:" << p_south->getY() << endl;
	}
	else
	{
		cout << "::: NO POINTER TO THE SOUTH OR POINTER IS NULL:::" << endl;
	}
	// ***************************************


	// ***************************************

	if (p_west != NULL)
	{
		cout << ":: WEST:  X:" << p_west->getX() << " Y:" << p_west->getY() << endl;
	}
	else
	{
		cout << "::: NO POINTER TO THE WEST OR POINTER IS NULL:::" << endl;
	}
	// ***************************************

	cout << "THE TYPE OF THIS CELL IS: ";

	if (type == START)
	{
		cout << "START" << endl;
	}
	else if (type == END)
	{
		cout << "END" << endl;
	}
	else if (type == BLOCKED)
	{
		cout << "BLOCKED" << endl;
	}
	else
	{
		cout << "FREE" << endl;
	}


	cout << "::::::::::::::::::::::::::::::::::::::::::::::::::" << endl;
}
void Cell::printType()
{
	if (type == START)
	{
		cout << "S";
	}
	if (type == END)
	{
		cout << "E";
	}
	if (type == BLOCKED)
	{
		cout << "B";
	}
	if (type == FREE)
	{
		cout << "F";
	}
}
// ********************************************************************************************************************************

