#pragma once

#include <iostream>
#include <iomanip>
#include <string>

using namespace std;

enum type
{
	FREE,
	BLOCKED,
	START,
	END
};

class Cell
{
public:

	// ***************************************
	//                CONSTRUCTORS/DESTRUCTORS
	Cell();
	Cell(int startX, int startY, int newType);
	~Cell();
	// ***************************************


	// ***************************************
	//                                 GETTERS
	bool hasBeenTraversed();
	int getY();
	int getX();
	bool areStart();
	bool areEnd();
	bool partOfPath();
	int getType();

	bool isNorthFree();
	bool isEastFree();
	bool isSouthFree();
	bool isWestFree();
	bool isAnyDirectionFree();

	Cell* getNorth();
	Cell* getEast();
	Cell* getSouth();
	Cell* getWest();
	// ***************************************


	// ***************************************
	//                                  SETERS
	void setNorth(Cell* p_point);
	void setSouth(Cell* p_point);
	void setEast(Cell* p_point);
	void setWest(Cell* p_point);
	void setSide(Cell* p_point, int direction);

	void setX(int newX);
	void setY(int newY);

	void changeType(int type);
	void printType();

	void setAsStart();
	void setAsEnd();

	void setType(int t);
	void setAsTraversed();

	void setAsPartOfPath();
	// ***************************************


	// ***************************************
	//                                   PRINT
	void printConnections();
	// ***************************************


private:

	Cell* p_north;
	Cell* p_south;
	Cell* p_east;
	Cell* p_west;

	int x;
	int y;

	bool traversed;
	bool free;
	bool start;
	bool end;

	bool isPartOfPath;

	int type;

};